import { Component } from '@angular/core';

@Component({
  selector: 'ngx-charts',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class ChartsComponent {
}
